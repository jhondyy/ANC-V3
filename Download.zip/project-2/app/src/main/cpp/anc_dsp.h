// ANC Lab Pro - DSP core (header-only, no Android dependencies).
// Rule: nothing below allocates, locks or logs inside process()/update().
// All memory is reserved in init(), which must be called OFF the audio thread.
#pragma once
#include <cmath>
#include <cstdint>
#include <vector>

namespace anc {

// Double-buffered history: data()[i] == x[n-i]. O(1) push, contiguous read.
struct History {
    std::vector<float> b; int n = 0, pos = 0; double power = 0;
    void init(int len) { n = len; b.assign(2 * len, 0.f); pos = 0; power = 0; }
    void push(float x) {
        float old = b[pos + n - 1];
        pos = pos == 0 ? n - 1 : pos - 1;
        b[pos] = b[pos + n] = x;
        power += double(x) * x - double(old) * old;
        if (power < 0) power = 0;
    }
    const float* data() const { return &b[pos]; }
};

class Fir {
public:
    void init(const float* h, int n) { taps.assign(h, h + n); hist.init(n); }
    float process(float x) {
        hist.push(x); const float* d = hist.data(); float a = 0;
        for (int i = 0; i < hist.n; ++i) a += taps[i] * d[i];
        return a;
    }
    std::vector<float> taps; History hist;
};

// Biquad, transposed direct form II. RBJ cookbook high-pass (DC/rumble guard).
class Biquad {
public:
    void highpass(float fs, float fc, float q = 0.7071f) {
        float w = 2 * float(M_PI) * fc / fs, c = std::cos(w), a = std::sin(w) / (2 * q), a0 = 1 + a;
        b0 = (1 + c) / 2 / a0; b1 = -(1 + c) / a0; b2 = b0; a1 = -2 * c / a0; a2 = (1 - a) / a0;
    }
    void lowpass(float fs, float fc, float q = 0.7071f) {
        float w = 2 * float(M_PI) * fc / fs, c = std::cos(w), a = std::sin(w) / (2 * q), a0 = 1 + a;
        b0 = (1 - c) / 2 / a0; b1 = (1 - c) / a0; b2 = b0; a1 = -2 * c / a0; a2 = (1 - a) / a0;
    }
    float process(float x) {
        float y = b0 * x + z1; z1 = b1 * x - a1 * y + z2; z2 = b2 * x - a2 * y; return y;
    }
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
};

// Plain NLMS: adaptive filter w so that w*x ~ d. For validation / system identification.
class Nlms {
public:
    void init(int L, float mu_) { h.init(L); w.assign(L, 0.f); mu = mu_; }
    float process(float x, float d, float* err) {
        h.push(x); const float* xd = h.data(); float y = 0;
        for (int i = 0; i < h.n; ++i) y += w[i] * xd[i];
        float e = d - y, g = mu * e / (1e-6f + float(h.power));
        for (int i = 0; i < h.n; ++i) w[i] += g * xd[i];
        if (err) *err = e;
        return y;
    }
    History h; std::vector<float> w; float mu = 0.01f;
};

// Filtered-x NLMS. Needs THREE distinct signals:
//   x : reference (noise measured BEFORE it reaches the ear / error mic)
//   e : error (residual measured at the error mic, after cancellation)
//   Shat : model of the secondary path (speaker -> error mic), measured offline.
// Per sample: y = output(x) -> send to speaker; later update(e).
class FxLms {
public:
    void init(int L, const float* shat, int S, float mu_, float leak_ = 1e-5f) {
        xh.init(L); fxh.init(L); w.assign(L, 0.f); sm.init(shat, S); mu = mu_; leak = leak_;
    }
    float output(float x) {
        xh.push(x); fxh.push(sm.process(x));
        const float* d = xh.data(); float y = 0;
        for (int i = 0; i < xh.n; ++i) y += w[i] * d[i];
        return y;
    }
    void update(float e) {
        const float* f = fxh.data(); float g = mu * e / (1e-6f + float(fxh.power));
        for (int i = 0; i < fxh.n; ++i) w[i] = (1 - leak) * w[i] - g * f[i];
    }
    void reset() { for (auto& v : w) v = 0; }
    History xh, fxh; Fir sm; std::vector<float> w; float mu = 0.01f, leak = 1e-5f;
};

// Output protection: hard limit, clip counting, sustained-clip and divergence trip.
// Once tripped, output is forced to 0 until reset() is called from the UI.
class Safety {
public:
    void configure(float maxOut_, int clipRun, float errRmsLimit_, float fs) {
        maxOut = maxOut_; clipRunLimit = clipRun; errLimit2 = errRmsLimit_ * errRmsLimit_;
        alpha = 1.f - std::exp(-1.f / (0.05f * fs));  // ~50 ms error RMS window
    }
    float process(float y) {
        if (tripped) return 0.f;
        if (!std::isfinite(y)) { trip(1); return 0.f; }
        bool clipped = std::fabs(y) > maxOut;
        clipRate += alpha * ((clipped ? 1.f : 0.f) - clipRate);   // clip density, ~50 ms window
        if (clipped) {
            ++clipTotal; ++clipRun_;
            if (clipRun_ >= clipRunLimit || clipRate > 0.25f) { trip(2); return 0.f; }
            return y > 0 ? maxOut : -maxOut;
        }
        clipRun_ = 0; return y;
    }
    void feedError(float e) {
        if (tripped) return;
        if (!std::isfinite(e)) { trip(1); return; }
        errPow += alpha * (e * e - errPow);
        if (errPow > errLimit2) trip(3);
    }
    void trip(int why) { tripped = true; reason = why; }  // 1 NaN, 2 clipping, 3 divergence
    void reset() { tripped = false; reason = 0; clipRun_ = 0; errPow = 0; clipRate = 0; }
    bool tripped = false; int reason = 0; uint64_t clipTotal = 0;
private:
    float maxOut = 0.3f, errLimit2 = 0.25f, alpha = 0.001f, errPow = 0, clipRate = 0; int clipRunLimit = 48, clipRun_ = 0;
};

// Narrowband (tonal) ANC with a SYNTHETIC reference at a user-chosen frequency.
// Needs only the error-mic signal e (plus a measured secondary-path gain/phase at that frequency).
// Works for steady tones (hum, fan, motor). Cancels at the MIC position only. Not broadband.
class NarrowbandAnc {
public:
    enum Cal { NONE = 0, RUNNING = 1, OK = 2, FAILED = 3 };
    static constexpr float kCalAmp = 0.03f, kMaxOut = 0.15f;
    void configure(float fs_, float f, float mu_) { fs = fs_; freq = f; mu = mu_; w = 2.0 * M_PI * f / fs_; }
    // ---- calibration: silence -> low-level probe tone -> demodulate the response at the mic ----
    void startCal() { n = 0; ph = 0; aC = aS = bC = bS = 0; cal = RUNNING; ancState = 0; }
    float stepCal(float e) {
        const long amb = long(0.4f * fs), ramp = long(0.2f * fs), settle = long(0.5f * fs), meas = long(1.0f * fs);
        double c = std::cos(ph), s = std::sin(ph); float y = 0;
        if (n < amb) { bC += e * c; bS += e * s; }                       // ambient level at f (output silent)
        else {
            long t = n - amb;
            y = kCalAmp * (t < ramp ? float(t) / ramp : 1.f) * float(c);
            if (t >= settle) { aC += e * c; aS += e * s; }
        }
        ++n; adv();
        if (n >= amb + settle + meas) {
            double C = 2 * aC / meas, S = 2 * aS / meas, amp = std::sqrt(C * C + S * S);
            double ambAmp = 2 * std::sqrt(bC * bC + bS * bS) / amb;
            if (!(amp > 0.003) || ambAmp > 0.2 * amp) cal = FAILED;       // too weak, or noise already at f
            else { sMag = amp / kCalAmp; sPhi = std::atan2(-S, C); calFreq = freq; cal = OK; }
        }
        return y;
    }
    // ---- ANC: 0.5 s baseline with silent output, then adapt two weights (cos/sin) ----
    void startAnc(Safety* s) { sf = s; n = 0; wc = ws = 0; bC = bS = bP = 0; ph = 0; ancState = 1; ec = es = 0; }
    float stepAnc(float e) {
        double c = std::cos(ph), s = std::sin(ph), y = 0;
        const long baseN = long(0.5f * fs);
        if (ancState == 1) {
            bC += e * c; bS += e * s; bP += double(e) * e;
            if (++n >= baseN) {
                baseAmp = 2 * std::sqrt(bC * bC + bS * bS) / baseN; ec = bC / baseN; es = bS / baseN;
                float lim = std::fmax(0.02f, 3.f * float(std::sqrt(bP / baseN)));
                sf->configure(kMaxOut, 48, lim, fs); ancState = 2;       // trip if residual grows >3x baseline
            }
        } else {
            y = wc * c + ws * s;
            double fc = sMag * std::cos(ph + sPhi), fq = sMag * std::sin(ph + sPhi), g = mu * e / (1e-6 + sMag * sMag);
            wc = clampw(wc - g * fc); ws = clampw(ws - g * fq);
            double a = 1.0 / (0.3 * fs); ec += a * (e * c - ec); es += a * (e * s - es);
            sf->feedError(e);
        }
        adv(); return float(y);
    }
    double attDb() const { return ancState == 2 && baseAmp > 0 ? 20 * std::log10(baseAmp / (2 * std::sqrt(ec * ec + es * es) + 1e-12)) : NAN; }
    double weightMag() const { return std::sqrt(wc * wc + ws * ws); }
    Cal cal = NONE; int ancState = 0;  // 0 off, 1 baseline, 2 adapting
    double sMag = 0, sPhi = 0, calFreq = 0, baseAmp = 0, wc = 0, ws = 0;
    float fs = 48000, freq = 200, mu = 3e-4f;
private:
    static double clampw(double v) { return v > 0.3 ? 0.3 : (v < -0.3 ? -0.3 : v); }
    void adv() { ph += w; if (ph > 2 * M_PI) ph -= 2 * M_PI; }
    double ph = 0, w = 0, aC = 0, aS = 0, bC = 0, bS = 0, bP = 0, ec = 0, es = 0; long n = 0; Safety* sf = nullptr;
};

}  // namespace anc
