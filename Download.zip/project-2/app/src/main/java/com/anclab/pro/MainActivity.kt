package com.anclab.pro

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
    override fun onStop() { NativeBridge.nativeStop(); super.onStop() }   // never keep the mic open in background
}

private val OUT_OK = setOf(AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE,
    AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET)

private fun findOut(am: AudioManager) = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.type in OUT_OK }
private fun findIn(am: AudioManager, phoneMic: Boolean): AudioDeviceInfo? {
    val ins = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
    if (phoneMic) return ins.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
    return ins.firstOrNull { it.type == AudioDeviceInfo.TYPE_USB_HEADSET || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET }
        ?: ins.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
}
private fun f1(v: Double) = String.format(Locale.US, "%.1f", v)
private fun dbs(v: Double) = if (v <= 0) "NA" else f1(20 * log10(v))
private fun nm(v: Double, fmt: (Double) -> String) = if (v < 0) "No medida" else fmt(v)

@Composable
fun App() {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var usePhoneMic by remember { mutableStateOf(false) }
    var freq by remember { mutableStateOf(200f) }
    var status by remember { mutableStateOf("Detenido") }
    var gain by remember { mutableStateOf(0.05f) }
    var stats by remember { mutableStateOf(DoubleArray(32) { -1.0 }) }
    var wave by remember { mutableStateOf(FloatArray(1024)) }
    var devInfo by remember { mutableStateOf("Sin sesión") }
    var sim by remember { mutableStateOf<List<String>>(emptyList()) }
    var simBusy by remember { mutableStateOf(false) }
    val log = remember { mutableStateListOf<String>() }

    fun addLog(ev: String) {
        val s = stats
        log.add("${System.currentTimeMillis()},$ev,${if (running) "REAL" else "DETENIDO"},${s[0]},${s[2]},${dbs(s[19])},${dbs(s[20])},${s[9]},${s[11] + s[12]}")
    }
    fun halt(reason: String) {
        NativeBridge.nativeEmergencyStop(); NativeBridge.nativeStop()
        running = false; status = "PARADA: $reason"; addLog(reason.replace(',', ';'))
    }
    fun start() {
        val out = findOut(am)
        if (out == null) { status = "Conecta audífonos (USB-C o cable). El altavoz del teléfono está bloqueado."; return }
        val inp = findIn(am, usePhoneMic)
        if (inp == null) { status = if (usePhoneMic) "No se encontró el micrófono del teléfono." else "No hay micrófono de entrada disponible."; return }
        val rc = NativeBridge.nativeStart(out.id, inp.id, gain)
        if (rc == 0) {
            running = true; status = "Monitor REAL activo"
            devInfo = "Salida: ${out.productName} (tipo ${out.type}) · Entrada: ${inp.productName} (tipo ${inp.type})"
            addLog("inicio")
        } else status = when (rc) { 1 -> "No se pudo abrir la salida"; 2 -> "No se pudo abrir la entrada"; else -> "No se pudo iniciar los streams" }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) start() else status = "Permiso de micrófono denegado"
    }

    LaunchedEffect(running) {
        var tick = 0
        while (running) {
            delay(80)
            val s = NativeBridge.nativeStats(); stats = s
            val snap = FloatArray(1024); NativeBridge.nativeSnapshot(snap); wave = snap
            if (s[15] > 0.5) { halt("Protección activada (motivo ${s[16].toInt()}: 1 NaN, 2 clipping, 3 inestabilidad)"); break }
            if (s[18] > 0.5) { halt("Error de stream o dispositivo desconectado"); break }
            if (s[17] < 0.5) { running = false; status = "Detenido"; break }
            if (findOut(am) == null) { halt("Audífonos desconectados"); break }
            if (++tick % 12 == 0) addLog("muestra")
        }
    }

    val bg = Color(0xFF0D1117); val card = Color(0xFF161B22); val mono = FontFamily.Monospace
    @Composable fun Card2(title: String, content: @Composable ColumnScope.() -> Unit) {
        Column(Modifier.fillMaxWidth().background(card, RoundedCornerShape(12.dp)).padding(12.dp)) {
            Text(title, fontSize = 13.sp, color = Color(0xFF58A6FF)); Spacer(Modifier.height(6.dp)); content()
        }
    }
    @Composable fun Row2(k: String, v: String) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(k, fontSize = 12.sp, color = Color(0xFF8B949E)); Text(v, fontSize = 12.sp, fontFamily = mono)
        }
    }

    Scaffold(containerColor = bg, bottomBar = {
        Button(onClick = { halt("Parada de emergencia") }, modifier = Modifier.fillMaxWidth().padding(8.dp).height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB62324))) { Text("PARADA DE EMERGENCIA", fontSize = 16.sp) }
    }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("ANC Lab Pro", fontSize = 22.sp)
            val (badge, bc) = if (running && stats[29] == 3.0) "REAL · ANC TONAL EXPERIMENTAL" to Color(0xFFD29922) else if (running) "REAL · medición con micrófono" to Color(0xFF2EA043) else "DETENIDO" to Color(0xFF6E7681)
            Text(badge, color = Color.White, fontSize = 12.sp, modifier = Modifier.background(bc, RoundedCornerShape(6.dp)).padding(6.dp, 3.dp))
            Card2("ADVERTENCIAS") {
                Text("Usa solo audífonos y volumen bajo. El audio procesado puede producir tonos fuertes o realimentación. " +
                    "Esto NO es protección auditiva. Es un instrumento experimental.", fontSize = 12.sp)
            }
            Button(onClick = {
                if (running) { NativeBridge.nativeStop(); running = false; status = "Detenido"; addLog("fin") }
                else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
                else perm.launch(Manifest.permission.RECORD_AUDIO)
            }, modifier = Modifier.fillMaxWidth().height(72.dp)) { Text(if (running) "DETENER" else "INICIAR MONITOR (bypass)", fontSize = 18.sp) }
            Text(status, fontSize = 13.sp)
            Card2("MICRÓFONO DE ENTRADA (detén antes de cambiar)") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !running, onClick = { usePhoneMic = false },
                        colors = ButtonDefaults.buttonColors(containerColor = if (!usePhoneMic) Color(0xFF1F6FEB) else Color(0xFF30363D))) { Text("Auriculares") }
                    Button(enabled = !running, onClick = { usePhoneMic = true },
                        colors = ButtonDefaults.buttonColors(containerColor = if (usePhoneMic) Color(0xFF1F6FEB) else Color(0xFF30363D))) { Text("Teléfono") }
                }
                Text("Android expone un solo micrófono interno lógico; no se puede elegir cada micrófono físico del teléfono por separado.", fontSize = 10.sp, color = Color(0xFF8B949E))
            }

            Card2("GANANCIA (máx. 0.25)") {
                Slider(value = gain, onValueChange = { gain = it; NativeBridge.nativeSetGain(it) }, valueRange = 0f..0.25f)
                Row2("Nivel de entrada RMS", if (running) "${dbs(stats[19])} dBFS" else "No medida")
                Row2("Pico de entrada", if (running) "${dbs(stats[20])} dBFS" else "No medida")
            }
            Card2("FORMA DE ONDA (entrada, REAL)") {
                val sc = max(0.02f, wave.maxOf { abs(it) })
                Canvas(Modifier.fillMaxWidth().height(90.dp)) {
                    val p = Path()
                    for (i in wave.indices step 2) {
                        val x = i * size.width / wave.size; val y = size.height / 2 - (wave[i] / sc).coerceIn(-1f, 1f) * size.height / 2
                        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                    }
                    drawPath(p, Color(0xFF3FB950), style = Stroke(2f))
                }
                Text("autoescala ×${f1(1.0 / sc)}", fontSize = 10.sp, color = Color(0xFF8B949E))
            }
            val fs = if (stats[0] > 0) stats[0] else 48000.0
            val mag = remember(wave) { fftMag(wave) }
            Card2("ESPECTRO FFT (0 – ${(fs / 2000).toInt()} kHz, -100…0 dBFS)") {
                Canvas(Modifier.fillMaxWidth().height(90.dp)) {
                    val bw = size.width / mag.size
                    for (i in mag.indices) {
                        val db = (20 * log10(mag[i].toDouble() + 1e-9)).coerceIn(-100.0, 0.0)
                        val h = ((db + 100) / 100 * size.height).toFloat()
                        drawLine(Color(0xFF58A6FF), Offset(i * bw, size.height), Offset(i * bw, size.height - h), strokeWidth = max(1f, bw))
                    }
                }
            }
            Card2("RUIDO POR BANDAS DE OCTAVA (dBFS relativo)") {
                val b = remember(mag, fs) { bandLevels(mag, fs) }
                BAND_CENTERS.forEachIndexed { i, c -> Row2("$c Hz", if (running) "${f1(b[i])}" else "No medida") }
            }
            Card2("DIAGNÓSTICO") {
                val s = stats
                Row2("Dispositivos", devInfo)
                Row2("Frecuencia de muestreo", nm(s[0]) { "${it.toInt()} Hz" })
                Row2("Búfer (frames) / ráfaga", nm(s[2]) { "${it.toInt()} / ${s[1].toInt()}" })
                Row2("Canales salida / entrada", nm(s[3]) { "${it.toInt()} / ${nm(s[4]) { v -> v.toInt().toString() }}" })
                Row2("Formato", if (s[0] > 0) "Float32 PCM" else "No medida")
                Row2("Acceso exclusivo salida / entrada", nm(s[13]) { (if (it > 0.5) "sí" else "no") + " / " + nm(s[14]) { v -> if (v > 0.5) "sí" else "no" } })
                Row2("Modo baja latencia", nm(s[22]) { if (it > 0.5) "sí" else "no" })
                Row2("Preset entrada", nm(s[21]) { if (it > 0.5) "UNPROCESSED" else "GENERIC (fallback)" })
                Row2("Latencia salida (Oboe)", nm(s[7]) { "${f1(it)} ms" })
                Row2("Latencia entrada (Oboe)", nm(s[8]) { "${f1(it)} ms" })
                Row2("Latencia total ida y vuelta", "No medida")
                Row2("Underruns (xruns)", nm(s[9]) { it.toInt().toString() })
                Row2("Lecturas cortas de entrada", nm(s[10]) { it.toInt().toString() })
                Row2("Clipping salida / entrada", nm(s[11]) { "${it.toInt()} / ${s[12].toInt()}" })
                Row2("Modelo ruta secundaria", "No calibrado")
                Row2("Estado algoritmo", if (!running) "Detenido" else when (s[29].toInt()) { 2 -> "Calibrando"; 3 -> "ANC tonal"; else -> "Monitor (bypass)" })
                Text("Latencia de Oboe = estimación por timestamps del stream, no una medición acústica. " +
                    "La ida y vuelta real requiere un test de loopback (pendiente).", fontSize = 10.sp, color = Color(0xFF8B949E))
            }
            Card2("SIMULACIÓN FxLMS (matemática offline, NO es medición real)") {
                Button(enabled = !simBusy, onClick = {
                    simBusy = true
                    scope.launch {
                        val r = withContext(Dispatchers.Default) {
                            listOf(NativeBridge.nativeSimulate(true, 10, 3, 0.02f), NativeBridge.nativeSimulate(false, 20, 3, 0.02f), NativeBridge.nativeSimulate(false, 2, 25, 0.02f))
                        }
                        sim = listOf("[SIMULACIÓN] tonos 200/440 Hz, caso causal: ${f1(r[0])} dB",
                            "[SIMULACIÓN] banda ancha, caso causal: ${f1(r[1])} dB",
                            "[SIMULACIÓN] banda ancha, latencia > retardo acústico: ${f1(r[2])} dB")
                        sim.forEach { log.add("${System.currentTimeMillis()},sim,SIMULACION,,,,,,,${it.replace(',', ';')}") }
                        simBusy = false
                    }
                }) { Text(if (simBusy) "Calculando…" else "Ejecutar simulación") }
                sim.forEach { Text(it, fontSize = 12.sp, color = Color(0xFFD29922)) }
            }
            Card2("ANC TONAL EXPERIMENTAL (ruido de una sola frecuencia)") {
                val s = stats; val mode = s[29].toInt()
                Text("Cancela un tono constante (zumbido, ventilador, motor) SOLO en la posición del micrófono, no en tu oído. " +
                    "No cancela voz ni ruido de banda ancha. Usa volumen bajo; la salida ANC está limitada y se corta sola si el error crece.", fontSize = 12.sp)
                Row2("Frecuencia objetivo", "${f1(freq.toDouble())} Hz")
                Slider(value = freq, onValueChange = { freq = it }, valueRange = 40f..600f, enabled = mode == 1)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = mode == 1, onClick = { freq = max(40f, freq - 0.5f) }) { Text("−0.5") }
                    Button(enabled = mode == 1, onClick = { freq = kotlin.math.min(600f, freq + 0.5f) }) { Text("+0.5") }
                    Button(enabled = mode == 1 && running, onClick = {
                        var k = 1; val lo = (40 / (fs / 1024)).toInt().coerceAtLeast(1); val hi = (600 / (fs / 1024)).toInt()
                        for (i in lo..hi) if (mag[i] > mag[k]) k = i
                        if (k > 1 && k < mag.size - 1) {
                            val a = kotlin.math.ln(mag[k - 1] + 1e-9); val b = kotlin.math.ln(mag[k] + 1e-9); val c = kotlin.math.ln(mag[k + 1] + 1e-9)
                            freq = ((k + 0.5 * (a - c) / (a - 2 * b + c)) * fs / 1024).toFloat().coerceIn(40f, 600f)
                        }
                    }) { Text("Pico FFT") }
                }
                Text("La frecuencia debe ser exacta (±1 Hz). Afínala con −/+ viendo el espectro.", fontSize = 10.sp, color = Color(0xFF8B949E))
                Button(enabled = running && mode == 1, onClick = { NativeBridge.nativeCommand(1, freq); addLog("calibrar ${f1(freq.toDouble())}Hz") }) { Text("1) Calibrar ruta secundaria") }
                Text("Hazlo en silencio (sin el ruido a cancelar), con los audífonos puestos y quietos. Reproduce un tono suave ~2 s.", fontSize = 10.sp, color = Color(0xFF8B949E))
                Row2("Calibración", when (s[23].toInt()) {
                    1 -> "Calibrando…"
                    2 -> "OK · ${f1(s[26])} Hz · |S|=${f1(s[24])} · fase ${f1(s[25])}°"
                    3 -> "FALLÓ (señal débil o ruido en esa frecuencia)"
                    else -> "No calibrado" })
                Button(enabled = running && s[23].toInt() == 2 && mode == 1, onClick = { NativeBridge.nativeCommand(2, freq); addLog("anc_on") }) { Text("2) ACTIVAR ANC a ${f1(s[26])} Hz") }
                if (mode == 3) Button(onClick = { NativeBridge.nativeCommand(3, freq); addLog("anc_off") }) { Text("Volver a monitor") }
                Row2("Fase ANC", when (s[27].toInt()) { 1 -> "Medición base (0.5 s)"; 2 -> "Adaptando"; else -> "No medida" })
                Row2("Atenuación del tono en el micrófono", if (s[28].isNaN()) "No medida" else "${f1(s[28])} dB (REAL)")
                Text("Valor positivo = baja; negativo = el ANC lo está empeorando: detén. Mide solo en el micrófono.", fontSize = 10.sp, color = Color(0xFF8B949E))
            }
            Card2("REGISTRO (${log.size} filas)") {
                Button(enabled = log.isNotEmpty(), onClick = {
                    val csv = "t_ms,evento,modo,fs,buffer,rms_dbfs,peak_dbfs,xruns,clips\n" + log.joinToString("\n")
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/csv"; putExtra(Intent.EXTRA_TEXT, csv) }, "Exportar CSV"))
                }) { Text("Exportar CSV") }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}
