// Host simulation of the tonal ANC mode (calibration + adaptation + safety). NOT a hardware test.
#include "../app/src/main/cpp/anc_dsp.h"
#include <cstdio>
#include <random>
using namespace anc;
struct R { int cal; double att, indep; bool trip; };
static R sim(double fNoise, float fRef, int D, bool noiseInCal, double phiErrDeg, float mu = 3e-4f) {
    const float fs = 48000; std::mt19937 rng(3); std::normal_distribution<float> nd(0, 0.002f);
    std::vector<float> St(D + 8, 0.f); St[D] = 0.6f; St[D + 1] = 0.25f; St[D + 3] = -0.1f;
    Fir S; S.init(St.data(), St.size()); Biquad hp, hp2; hp.highpass(fs, 20); hp2.highpass(fs, 20);
    Safety sf; sf.configure(0.3f, 48, 1.0f, fs);
    NarrowbandAnc nb; nb.configure(fs, fRef, mu);
    long n = 0; float y = 0;
    auto d = [&](bool tone) { return nd(rng) + (tone ? 0.1f * float(std::sin(2 * M_PI * fNoise * n / fs + 0.7)) : 0.f); };
    nb.startCal();
    while (nb.cal == NarrowbandAnc::RUNNING) { float e = hp.process(d(noiseInCal) + S.process(y)); y = sf.process(nb.stepCal(e)); ++n; }
    if (nb.cal != NarrowbandAnc::OK) return {int(nb.cal), 0, 0, false};
    nb.sPhi += phiErrDeg * M_PI / 180; nb.startAnc(&sf);
    double sd = 0, se = 0; long N = 8 * 48000;
    for (long k = 0; k < N; ++k) {
        float dn = d(true); float e = hp.process(dn + S.process(y));
        y = sf.process(nb.stepAnc(e)); ++n;
        float dh = hp2.process(dn); if (k > N - 48000) { sd += dh * dh; se += e * e; }
    }
    return {int(nb.cal), nb.attDb(), 10 * std::log10(sd / (se + 1e-30)), sf.tripped};
}
static int fails = 0;
#define CHECK(c, m) do { bool ok = (c); printf("  [%s] %s\n", ok ? "PASS" : "FAIL", m); if (!ok) ++fails; } while (0)
int main() {
    puts("A) 200 Hz tone, loop delay 0.4 ms");  { R r = sim(200, 200, 20, false, 0);  printf("  att(self)=%.1f dB, att(independent)=%.1f dB\n", r.att, r.indep); CHECK(r.indep > 20 && !r.trip, ">20 dB"); }
    puts("B) 200 Hz tone, loop delay 21 ms (USB-like)"); { R r = sim(200, 200, 1000, false, 0); printf("  att(self)=%.1f dB, att(independent)=%.1f dB\n", r.att, r.indep); CHECK(r.indep > 20 && !r.trip, ">20 dB even with 21 ms latency (tonal only)"); }
    puts("C) 100 Hz tone, 10 ms"); { R r = sim(100, 100, 480, false, 0); printf("  att(independent)=%.1f dB\n", r.indep); CHECK(r.indep > 20 && !r.trip, ">20 dB"); }
    puts("D) Calibrating while the noise tone is present"); { R r = sim(200, 200, 100, true, 0); CHECK(r.cal == NarrowbandAnc::FAILED, "calibration rejected"); }
    puts("E) Phase model wrong by 120 deg (bad calibration)"); { R r = sim(200, 200, 100, false, 120); printf("  tripped=%d att=%.1f dB\n", r.trip, r.indep); CHECK(r.trip || r.indep < 3, "safety stops it or it does not claim success"); }
    puts("F) Reference 1.5 Hz off the real tone (info)"); { R r = sim(201.5, 200, 100, false, 0); printf("  att(independent)=%.1f dB tripped=%d\n", r.indep, r.trip); }
    printf("\n%s\n", fails ? "FAILED" : "ALL PASSED"); return fails;
}
